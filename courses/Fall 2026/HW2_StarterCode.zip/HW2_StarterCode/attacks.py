"""
attacks.py

Homework 2 student starter file.

Implement the five functions below. You may add helper functions, but do not
change any required function name or signature.

Submit this file together with answers.pdf. Do not modify or submit the other
starter-package files.
"""

from __future__ import annotations

CTR_COUNTER_SIZE = 16
AES_BLOCK_SIZE = 16


def change_amount(ciphertext: bytes) -> bytes:
    """
    Task 1: CTR bit-flipping attack.

    The ciphertext encrypts exactly:
        b"from=alice&to=bob&amount=1000"

    Ciphertext format:
        16-byte ctr || CTR ciphertext

    Return a modified ciphertext that decrypts to:
        b"from=alice&to=bob&amount=9000"

    Do not use a decryption oracle.
    """
    raise NotImplementedError("TODO")


def recover_ctr_byte(ciphertext: bytes, position: int, oracle) -> int:
    """
    Task 3: Recover one message byte using only the null-byte format oracle.

    Args:
        ciphertext: 16-byte ctr || CTR ciphertext.
        position: zero-based byte position in the message.
        oracle: callable oracle(modified_ciphertext) -> bool.

    Returns:
        The recovered message byte as an int in [0, 255].

    Assumption:
        The original message contains no 0x00 bytes.

    Query limit:
        At most 255 oracle queries.
    """
    raise NotImplementedError("TODO")


def recover_ctr(ciphertext: bytes, oracle) -> bytes:
    """
    Task 5: Recover the complete null-free message encrypted under CTR mode.

    The attack must work for arbitrary binary messages; do not assume that the
    message is ASCII or printable.

    Query limit:
        At most 255 * message_length oracle queries.
    """
    raise NotImplementedError("TODO")


def recover_cbc_block(previous_block: bytes, block: bytes, oracle) -> bytes:
    """
    Task 9: Recover one 16-byte CBC message block using the padding oracle.

    Args:
        previous_block: the 16-byte block immediately preceding block (or IV).
        block: the 16-byte ciphertext block whose message block is recovered.
        oracle: callable oracle(modified_ciphertext) -> bool.

    Returns:
        f_k^{-1}(block) XOR previous_block.

    The oracle accepts a complete CBC ciphertext and returns True iff the
    resulting decrypted message has valid PKCS#7 padding.

    Your implementation must handle cases in which more than one modification
    appears to produce valid padding.
    """
    raise NotImplementedError("TODO")


def recover_cbc(ciphertext: bytes, oracle) -> bytes:
    """
    Task 10: Recover the complete unpadded CBC message.

    Ciphertext format:
        IV || C1 || C2 || ... || Cn

    Recover every message block, concatenate the blocks, remove PKCS#7 padding,
    and return the original unpadded message.
    """
    raise NotImplementedError("TODO")
